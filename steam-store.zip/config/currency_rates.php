<?php 
return [
    'api_url' => 'https://freecurrencyapi.net/api/v2/latest?apikey=0482f7b0-7c56-11ec-8dfd-87dd45b39b17&base_currency=',
];