
<?php $__env->startSection('title', 'Главная'); ?>
<?php $__env->startSection('content'); ?>
    <div class="starter-template">
        <h1><?php echo app('translator')->get('main.all_products'); ?></h1>
        <form method="GET" action="<?php echo e(route("index")); ?>">
            <div class="filters row">
                <div class="col-sm-6 col-md-3">
                    <label for="price_from"><?php echo app('translator')->get('main.price_from'); ?>
                        <input type="text" name="price_from" id="price_from" size="6" value="<?php echo e(request()->price_from); ?>">
                    </label>
                    <label for="price_to"><?php echo app('translator')->get('main.price_to'); ?>
                        <input type="text" name="price_to" id="price_to" size="6"  value="<?php echo e(request()->price_to); ?>">
                    </label>
                </div>
                <div class="col-sm-2 col-md-2">
                    <label for="hit">
                        <input type="checkbox" name="hit" id="hit" <?php if(request()->has('hit')): ?> checked <?php endif; ?>> <?php echo app('translator')->get('main.properties.hit'); ?>
                    </label>
                </div>
                <div class="col-sm-2 col-md-2">
                    <label for="new">
                        <input type="checkbox" name="new" id="new" <?php if(request()->has('new')): ?> checked <?php endif; ?>> <?php echo app('translator')->get('main.properties.new'); ?>
                    </label>
                </div>
                <div class="col-sm-2 col-md-2">
                    <label for="recommended">
                        <input type="checkbox" name="recommended" id="recommended" <?php if(request()->has('recommended')): ?> checked <?php endif; ?>> <?php echo app('translator')->get('main.properties.recommend'); ?>
                    </label>
                </div>
                <div class="col-sm-6 col-md-3">
                    <label for="word"><?php echo app('translator')->get('main.contains_in_name'); ?>
                        <input type="text" name="word" id="word" size="15"  value="<?php echo e(request()->word); ?>">
                    </label>
                </div>
                <div class="col-sm-6 col-md-3">
                    <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('main.filter'); ?>
                    </button>
                    <a href="<?php echo e(route("index")); ?>" class="btn btn-warning"><?php echo app('translator')->get('main.reset'); ?>
                    </a>
                </div>
            </div>
        </form>
        <?php $__currentLoopData = $skus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('card', compact('sku'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e($skus->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\home\store-laravel\resources\views/index.blade.php ENDPATH**/ ?>