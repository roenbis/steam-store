
<?php $__env->startSection('title', $sku->product->__('name')); ?>
<?php $__env->startSection('content'); ?>
    <div class="starter-template">
        <h1><?php echo e($sku->product->__('name')); ?></h1>
        <h2><?php echo e($sku->product->category->__('name')); ?></h2>
        <p>Цена: <b><?php echo e($sku->price); ?> <?php echo e($currencySymbol); ?></b></p>
        <?php if(isset($sku->product->properties)): ?>
            <?php $__currentLoopData = $sku->propertyOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propertyOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h5> <?php echo e($propertyOption->property->__('name')); ?> : <b><?php echo e($propertyOption->__('name')); ?></b></h5>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <img src="<?php echo e(Storage::url($sku->product->image)); ?>" height="300" alt="<?php echo e($sku->product->__('name')); ?> image">
        <p><?php echo e($sku->product->__('description')); ?></p>
        <p>Количество на складе: <b><?php echo e($sku->count > 1 ? $sku->count : 0); ?> шт.</b></p>
        <?php if($sku->isAvailable()): ?>
            <form action="<?php echo e(route('basket-add', $sku->product)); ?>" method="POST">
            <button type="submit"
            class="btn btn-success">Добавить в корзину</button>
            <?php echo csrf_field(); ?>
            </form>
        <?php else: ?>
            <span>Товар распродан</span>
            <br>
            <span>Сообщить мне когда товар станет доступен</span>
            <div class="warning"><?php if($errors->get('email')): ?>
                <?php echo $errors->get('email')[0]; ?>

            <?php endif; ?></div>

            <form action="<?php echo e(route('subscription', $sku)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="text" name="email">
                <button type="submit">Подписаться на товар</button>
            </form>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\home\store-laravel\resources\views/product.blade.php ENDPATH**/ ?>