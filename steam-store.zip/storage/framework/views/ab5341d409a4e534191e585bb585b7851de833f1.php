
<?php $__env->startSection('title', 'Корзина'); ?>
<?php $__env->startSection('content'); ?>
    <div class="starter-template">
        <h1>Корзина</h1>
        <p>Оформление заказа</p>
        <div class="panel">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>Название</th>
                    <th>Кол-во</th>
                    <th>Цена</th>
                    <th>Стоимость</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $order->skus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($sku->countInOrder > 0): ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('sku', [$sku->product->category->code, $sku->product->code, $sku])); ?>">
                                    <img height="56px" src="<?php echo e(Storage::url($sku->product->image)); ?>">
                                    <?php echo e($sku->product->__('name')); ?>

                                </a>
                            </td>
                            <td><span class="badge"><?php echo e($sku->countInOrder); ?></span>
                                <div class="btn-group form-inline">
                                    <form action="<?php echo e(route('basket-remove', $sku)); ?>" method="POST">
                                        <button type="submit" class="btn btn-danger">
                                            <span class="glyphicon glyphicon-minus" aria-hidden="true"></span>
                                        </button>
                                        <?php echo csrf_field(); ?>
                                    </form>
                                    <form action="<?php echo e(route('basket-add', $sku)); ?>" method="POST">
                                        <button type="submit" class="btn btn-success"
                                        ><span
                                                class="glyphicon glyphicon-plus" aria-hidden="true"></span>
                                        </button>
                                        <?php echo csrf_field(); ?>
                                    </form>

                                </div>
                            </td>
                            <td><?php echo e($sku->price); ?> <?php echo e($currencySymbol); ?></td>
                            <td><?php echo e($sku->price * ($sku->countInOrder)); ?> <?php echo e($currencySymbol); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="3"><?php echo app('translator')->get('basket.full_cost'); ?></td>
                    <?php if($order->hasCoupon()): ?>
                        <td><strike><?php echo e($order->getFullSum(false)); ?></strike>  ->  <?php echo e(round($order->getFullSum(true),2)); ?> <?php echo e($currencySymbol); ?></td>

                    <?php else: ?>
                        <td><?php echo e($order->getFullSum()); ?> <?php echo e($currencySymbol); ?></td>

                    <?php endif; ?>
                </tr>
                </tbody>
            </table>
            <?php if(!$order->hasCoupon()): ?>
            <div class="row">
                <div class="form-inline pull-right">
                    <form method="POST" action="<?php echo e(route('set-coupon')); ?>">
                        <?php echo csrf_field(); ?>
                        <label for="coupon">
                            Добавить купон:
                        </label>
                        <input class="form-control" type="text" name="coupon" id="coupon" value="<?php echo e(request()->coupon); ?>">
                        <button type="submit" class="btn btn-success">Применить</button>

                    </form>

                </div>
            </div>
            <?php $__errorArgs = ['coupon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger" ><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php else: ?>
                <div>Вы используете купон № <?php echo e($order->coupon->code); ?></div>
            <?php endif; ?>
            <br>
            <div class="btn-group pull-right" role="group">
                <a type="button" class="btn btn-success" href="<?php echo e(route('basket-place')); ?>">Оформить заказ</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\home\store-laravel\resources\views/basket.blade.php ENDPATH**/ ?>