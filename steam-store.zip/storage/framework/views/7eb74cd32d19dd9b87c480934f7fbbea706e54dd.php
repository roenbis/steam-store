<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="yandex-verification" content="9974e0eee0f21447"/>
        <title><?php echo app('translator')->get('main.online_shop'); ?>: <?php echo $__env->yieldContent('title'); ?> </title>
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <script src="/js/jquery.min.js"></script>
        <script src="/js/bootstrap.min.js"></script>
        <link href="/css/bootstrap.min.css" rel="stylesheet">
        <link href="/css/starter-template.css" rel="stylesheet">

    </head>
    <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <a class="navbar-brand" href="<?php echo e(route('index')); ?>"><?php echo e(__('main.online_shop')); ?></a>
            </div>
            <div id="navbar" class="collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li <?php echo Route::currentRouteNamed('index') ? 'class="active"' : '' ?>><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.all_products'); ?></a></li>
                    <li <?php echo Route::currentRouteNamed('categor*') ? 'class="active"' : '' ?>><a href="<?php echo e(route('categories')); ?>"><?php echo app('translator')->get('main.categories'); ?></a></li>
                    <li ><a href="<?php echo e(route('basket')); ?>"><?php echo app('translator')->get('main.to_basket'); ?></a></li>
                    <li><a href="<?php echo e(route('locale', __('main.set_lang'))); ?>"><?php echo e(__('main.set_lang')); ?></a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e($currencySymbol); ?><span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('currency', $currency->code)); ?>"><?php echo e($currency->symbol); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <?php if(auth()->guard()->guest()): ?>
                    <li><a href="<?php echo e(route('login')); ?>"><?php echo app('translator')->get('main.login'); ?></a></li>
                    <?php endif; ?>
                    <?php if(auth()->guard()->check()): ?>
                    <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
                    <li class='nav-item'><a href="<?php echo e(route('orders')); ?>"><?php echo app('translator')->get('main.admin_panel'); ?></a></li>
                    <?php else: ?>
                    <li class='nav-item'><a href="<?php echo e(route('person.orders.index')); ?>"><?php echo app('translator')->get('main.my_orders'); ?></a></li>
                    <?php endif; ?>
                    <li class='nav-item'><a href="<?php echo e(route('logout')); ?>"><?php echo app('translator')->get('main.logout'); ?></a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <div class='container'>
        <div class="starter-template">
            <?php if(session()->has('success')): ?>
                <p class="alert alert-success"><?php echo e(session()->get('success')); ?></p>
            <?php endif; ?>
            <?php if(session()->has('warning')): ?>
                <p class="alert alert-warning"><?php echo e(session()->get('warning')); ?></p>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <footer class="footer navbar-fixed-bottom">
        <div class="container ">
            <div class="row">
                <div class="col-lg-6"><p>Категории товаров</p>
                    <ul>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('category', $category->code)); ?>"><?php echo e($category->__('name')); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="col-lg-6"><p>Самые популярные товары</p>
                    <ul>
                        <?php $__currentLoopData = $bestSkus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bestSku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('sku', [$bestSku->product->category->code, $bestSku->product->code, $bestSku])); ?>"><?php echo e($bestSku->product->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    </body>
</html>
<?php /**PATH C:\OSPanel\home\store-laravel\resources\views/master.blade.php ENDPATH**/ ?>