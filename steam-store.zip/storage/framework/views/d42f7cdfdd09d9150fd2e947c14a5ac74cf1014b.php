<div class="col-sm-6 col-md-4">
    <div class="thumbnail">
        <div class="labels">
            <?php if($sku->product->isNew()): ?><span class="badge badge-success">Новинка</span><?php endif; ?>
            <?php if($sku->product->isRecommended()): ?><span class="badge badge-warning">Рекомендуемые</span><?php endif; ?>
            <?php if($sku->product->isHit()): ?><span class="badge badge-danger">Хит продаж</span><?php endif; ?>
        </div>
        <a href="<?php echo e(route('sku', [$sku->product->category->code, $sku->product->code, $sku])); ?>">
            <img src="<?php echo e(Storage::url($sku->product->image)); ?>" alt="<?php echo e($sku->product->__('name')); ?> image">
        </a>
        <div class="caption">
            <a href="<?php echo e(route('sku', [$sku->product->category->code, $sku->product->code, $sku])); ?>">
                <h3><?php echo e($sku->product->__('name')); ?></h3>
            </a>

                <?php if(isset($sku->product->properties)): ?>
                    <?php $__currentLoopData = $sku->propertyOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propertyOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5> <?php echo e($propertyOption->property->__('name')); ?> : <b><?php echo e($propertyOption->__('name')); ?></b></h5>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            <p><?php echo e($sku->price); ?> <?php echo e($currencySymbol); ?></p>
            <form action="<?php echo e(route('basket-add', $sku)); ?>" method="POST">
                <?php if($sku->isAvailable()): ?>

                <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('product.add_to_cart'); ?></button>
                <?php else: ?>
                <?php echo app('translator')->get('product.product_soldout'); ?>
                <?php endif; ?>
                <a href="<?php echo e(route('sku', [$sku->product->category->code, $sku->product->code, $sku])); ?>" class="btn btn-default" role="button"><?php echo app('translator')->get('product.more_info'); ?></a>
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\OSPanel\home\store-laravel\resources\views/card.blade.php ENDPATH**/ ?>