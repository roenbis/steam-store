<?php
return [
    'your_order_confirmed' => 'Your order has been taken into processing!',
    'full_cost' => 'Full cost:'

];
