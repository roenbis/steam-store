<?php 
return [
    'order_created' => 'Your order created',
    'your_order_sum' => 'Order summ is: ',
];