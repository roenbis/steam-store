<?php
return [
    'add_to_cart' => 'Add to cart',
    'product_soldout' => 'Product is sold out',
    'more_info' => 'More info'
];