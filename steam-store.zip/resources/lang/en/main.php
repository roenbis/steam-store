<?php
return [
    'online_shop' => 'Steam Store',
    'all_products' => 'All products',
    'set_lang' => "ru",
    'price_from' => 'Price from',
    'price_to' => 'Price to',
    'contains_in_name' => 'Name contains:',
    'filter' => 'Filter',
    'reset' => 'Reset',
    'categories' => 'Categories',
    'to_basket' => 'Go to basket',
    'project_reset' => 'Reset of project is completed',
    'login' => 'Login',
    'admin_panel' => "Admin's",
    'my_orders' => 'My orders',
    'logout' => 'Logout',
    'properties' => [
        'hit' => 'Hit',
        'recommend' => 'Recommend',
        'new' => 'New',
    ],
];
