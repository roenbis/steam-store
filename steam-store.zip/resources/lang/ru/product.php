<?php
return [
    'add_to_cart' => 'В корзину',
    'product_soldout' => 'Продукт распродан',
    'more_info' => 'Подробнее'
];