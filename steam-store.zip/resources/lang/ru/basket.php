<?php
return [
    'your_order_confirmed' => 'Ваш заказ был принят в обработку!',
    'full_cost' => 'Общая стоимость:'
];
