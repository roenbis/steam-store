<?php 
return [
    'order_created' => 'Ваш заказ создан',
    'your_order_sum' => 'Cумма заказа',
];