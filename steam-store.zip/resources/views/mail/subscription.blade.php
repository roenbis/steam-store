Уважаемый клиент, товар {{$sku->product->__('name')}} появился в наличии,
<a href="{{route('sku', [$sku->product->category->code, $sku->product->code, $sku])}}">узнать подробности</a>
<br>
<br>
<p>С уважением,</p>
<p>Ваш Steam-Store</p>
